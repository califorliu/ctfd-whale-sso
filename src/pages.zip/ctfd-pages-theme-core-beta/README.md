# ctfd-pages-theme

`core-beta` is forked from https://github.com/CTFd/core-beta

将题目分类分页，目前用于 https://ctf.xidian.edu.cn 以及 https://ctf.show

## 食用方式

clone到themes目录下，在后台切换到相应主题。  
请自行在CTFd中添加`/api/v1/challenges/categories`路由用于枚举题目类型

## tldr

```sh
git clone https://github.com/CTFd/CTFd
git clone https://github.com/frankli0324/ctfd-pages-theme CTFd/themes/pages
```
